package com.infy.OrderMS.dto;

import java.time.LocalDate;

import com.infy.OrderMS.entity.OrderDetails;

public class OrderDetailsDTO {

	int orderId;
	int buyerId;
	double amount;
	LocalDate date;
	String address;
	String status;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public OrderDetailsDTO(int orderId,int buyerId,double amount,LocalDate date,String address,String status)
	{
		this();
		this.orderId=orderId;
		this.buyerId=buyerId;
		this.amount=amount;
		this.date=date;
		this.address=address;
		this.status=status;
		
	}
	
	public OrderDetailsDTO() {
		super();
	}
	
	//convert DTO to ENTITY
	public OrderDetails createOrder()
	{
		OrderDetails order=new OrderDetails();
		order.setOrderId(this.getOrderId());
		order.setBuyerId(this.getBuyerId());
		order.setAmount(this.getAmount());
		order.setDate(this.getDate());
		order.setAddress(this.getAddress());
		order.setStatus(this.getStatus());
		return order;
	}
	
	@Override
	public String toString() {
		return "OrderDetailsDTO [orderId=" + orderId + ", buyerId=" + buyerId + "]";
	}
}
